function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6PI0mgUhad2":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

